# ZarxPro

Mobile-first cyber/gaming-style crypto dashboard.

Set `SUPABASE_URL` and `SUPABASE_ANON_KEY` (or `SUPABASE_PUBLISHABLE_KEY`) in Vercel. The app reads `public.signals`. Market prices use CoinGecko. Portfolio is paper/demo only.
