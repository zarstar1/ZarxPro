import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {title:"ZarxPro — Read The Market. Play Smart.",description:"Colorful mobile-first crypto dashboard."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}