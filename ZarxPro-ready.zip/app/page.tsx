 "use client";
import {useEffect,useState} from "react";
type Signal={id:string;symbol:string;direction:string;timeframe:string;entry:number;stop_loss:number;take_profit:number;confidence:number;status:string;engine?:string};
const tabs=["HOME","MARKET","SIGNALS","SPECIAL","HISTORY","AIRDROPS","PORTFOLIO"];
const demo={BTC:106240,ETH:4210,SOL:196.2};
const money=(n:number)=>n>=1000?n.toLocaleString(undefined,{maximumFractionDigits:0}):n.toLocaleString(undefined,{maximumFractionDigits:4});
export default function Home(){const[tab,setTab]=useState("HOME"),[signals,setSignals]=useState<Signal[]>([]),[prices,setPrices]=useState(demo),[source,setSource]=useState(""),[cash,setCash]=useState(60);
useEffect(()=>{fetch("/api/signals").then(r=>r.json()).then(x=>{setSignals(x.signals||[]);setSource(x.source||"")}).catch(()=>{});fetch("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana&vs_currencies=usd").then(r=>r.json()).then(x=>setPrices({BTC:x.bitcoin?.usd||demo.BTC,ETH:x.ethereum?.usd||demo.ETH,SOL:x.solana?.usd||demo.SOL})).catch(()=>{})},[]);
const active=signals.filter(s=>String(s.status).toUpperCase()==="ACTIVE");
return <main><header><div className="brand"><span>Z</span><b>ZARX<span>PRO</span><small>CRYPTO ARCADE</small></b></div><i>● LIVE</i></header>
<section className="hero"><p>◆ MARKET COMMAND CENTER</p><h1>READ THE MARKET.<br/><em>PLAY SMART.</em></h1><small>Signals, market pulse and portfolio tools — built for fast decisions.</small><div className="stats"><div>BTC <b>${money(prices.BTC)}</b></div><div>ETH <b>${money(prices.ETH)}</b></div><div>SOL <b>${money(prices.SOL)}</b></div></div></section>
<nav>{tabs.map(t=><button className={tab===t?"on":""} onClick={()=>setTab(t)} key={t}>{t}</button>)}</nav><section className="content">
{tab==="HOME"&&<><Title n="01" t="ACTIVE SIGNALS"/><div className="grid">{active.slice(0,3).map(s=><Card s={s} key={s.id}/>)}</div><Title n="02" t="MARKET PULSE"/><Market prices={prices}/></>}
{tab==="MARKET"&&<><Title n="03" t="MARKET RADAR"/><Market prices={prices}/></>}
{tab==="SIGNALS"&&<><Title n="04" t="ALL SIGNALS"/><div className="grid">{signals.map(s=><Card s={s} key={s.id}/>)}</div><small className="muted">Source: {source||"demo"}</small></>}
{tab==="SPECIAL"&&<Panel title="ZARX SPECIAL">⚡ SCALP MODE — 15M → 4H<div className="feature">🎮 ARCADE XP <span>Coming soon</span></div></Panel>}
{tab==="HISTORY"&&<Panel title="TRADE HISTORY">Your local play-money activity will appear here.</Panel>}
{tab==="AIRDROPS"&&<Panel title="AIRDROP ZONE"><p>Track opportunities safely.</p><strong className="warn">⚠ NEVER SHARE SEED PHRASES OR PRIVATE KEYS.</strong></Panel>}
{tab==="PORTFOLIO"&&<Panel title="PAPER PORTFOLIO"><p>No real orders are placed.</p><div className="cash"><small>VIRTUAL BALANCE</small><b>${cash.toFixed(2)}</b></div><button className="claim" onClick={()=>setCash(60)}>RESET TO $60</button></Panel>}
</section><footer><b>ZARXPRO</b><span>READ THE MARKET · PLAY SMART</span><small>Paper tools only · Not financial advice</small></footer></main>}
function Title({n,t}:{n:string;t:string}){return <div className="title"><span>{n}</span><h2>{t}</h2></div>}
function Card({s}:{s:Signal}){let sh=String(s.direction).toUpperCase()==="SHORT";return <article className={"card "+(sh?"short":"")}><div className="row"><b>{s.symbol}</b><small>{s.timeframe}</small></div><div className="dir">{sh?"↘":"↗"} {s.direction}</div><div className="levels"><div><small>ENTRY</small><b>{s.entry}</b></div><div><small>SL</small><b>{s.stop_loss}</b></div><div><small>TP</small><b>{s.take_profit}</b></div></div><div className="bar"><i style={{width:`${Math.min(100,Math.max(0,s.confidence||0))}%`}}/></div><small>{s.confidence}% CONFIDENCE · {s.status}</small></article>}
function Market({prices}:{prices:Record<string,number>}){return <div className="market">{Object.entries(prices).map((x,i)=><div className="mrow" key={x[0]}><b>{x[0]}<small>/USDT</small></b><span>▂▅▃▇▅█▆</span><strong>${money(x[1])}</strong><em className={i===2?"down":""}>{i===2?"-0.8%":"+1.2%"}</em></div>)}</div>}
function Panel({title,children}:{title:string;children:React.ReactNode}){return <div className="panel"><Title n="◆" t={title}/><p>{children}</p></div>}